"use strict";

var b1 = new Vue({
  el: '#Funny',
  data: {
    seen: true
  }
})

var b2 = new Vue({
  el: '#Clap',
  data: {
    seen: true
  }
})

var b3 = new Vue({
  el: '#Help',
  data: {
    seen: true
  }
})

var b4 = new Vue({
  el: '#Thanks',
  data: {
    seen: true
  }
})
var b5 = new Vue({
  el: '#Goodmorning',
  data: {
    seen: true
  }
})

var b6 = new Vue({
  el: '#Greetings',
  data: {
    seen: true
  }
})

var b7 = new Vue({
  el: '#Finally',
  data: {
    seen: true
  }
})

var b8 = new Vue({
  el: '#Group',
  data: {
    seen: true
  }
})

var b9 = new Vue({
  el: '#Session',
  data: {
    seen: true
  }
})

var b10 = new Vue({
  el: '#Wait',
  data: {
    seen: true
  }
})

var b11 = new Vue({
  el: '#TooQuick',
  data: {
    seen: true
  }
})

var b12 = new Vue({
  el: '#AhHa',
  data: {
    seen: true
  }
})

var b13 = new Vue({
  el: '#Onemore',
  data: {
    seen: true
  }
})

var b14 = new Vue({
  el: '#Great',
  data: {
    seen: true
  }
})

var b15 = new Vue({
  el: '#Share',
  data: {
    seen: true
  }
})

var b16 = new Vue({
  el: '#Suggestion',
  data: {
    seen: true
  }
})

var b17 = new Vue({
  el: '#Eiken',
  data: {
    seen: true
  }
})

var b18 = new Vue({
  el: '#Finished',
  data: {
    seen: true
  }
})

var b19 = new Vue({
  el: '#Question',
  data: {
    seen: true
  }
})

var b20 = new Vue({
  el: '#Write',
  data: {
    seen: true
  }
})